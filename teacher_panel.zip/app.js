async function loadList(){
  const listEl = document.getElementById("list");
  const content = document.getElementById("content");
  try{
    const r = await fetch("../results/list.json?nocache=" + Date.now());
    const files = await r.json();
    listEl.innerHTML = "<h2>Доступные работы:</h2>";
    files.forEach(f=>{
      const a=document.createElement("a");
      a.textContent=f;
      a.onclick=()=>loadFile(f);
      listEl.appendChild(a);
    });
  }catch(e){
    listEl.textContent="Ошибка загрузки списка работ.";
  }
}

async function loadFile(name){
  const content = document.getElementById("content");
  content.textContent="Загрузка...";
  try{
    const r = await fetch("../results/" + name + "?nocache=" + Date.now());
    const json = await r.json();
    content.textContent = JSON.stringify(json,null,2);
  }catch(e){
    content.textContent="Ошибка загрузки файла.";
  }
}

loadList();
